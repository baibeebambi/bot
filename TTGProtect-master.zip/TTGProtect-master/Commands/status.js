const Discord = require('discord.js');

module.exports = async(bot, msg, args) => {
	msg.channel.send(`i thonk i'm online`)
}