# TTGProtect
The discord moderation bot for @everyone, open-source

## Self-Hosting
1. Clone the repo
2. Fill out the config file `./Configuration/config.json`
3. Run `npm install` to install everything required
4. Run the bot! (`node bot.js`)

## Setting up the dashboard
Coming Soon
